const express = require('express');
const app = express();

app.use(express.json());

const response = {
  checkValue: {
    status: "failure",
    message: "Please provide input"
  },
  invalidInputs: {
    status: "Error",
    message: "Invalid data types"
  },
  underflow: {
    status: "Error",
    message: "Underflow"
  },
  overflow: {
    status: "Error",
    message: "Overflow"
  }
};

app.get("/", (req, res) => {
  res.send("Hello World!");
});

function checkValues(num1, num2) {
  if (num1 === "" || num2 === "") {
    return false;
  }
  return true;
}

function validateDataType(num1, num2) {
  if (isNaN(num1) || isNaN(num2)) {
    return false;
  }
  return true;
}

app.post("/add", (req, res) => {
  let num1 = req.body.num1;
  let num2 = req.body.num2;

  if (!checkValues(num1, num2)) {
    return res.status(400).json(response.checkValue);
  }
  if (!validateDataType(num1, num2)) {
    return res.status(400).json(response.invalidInputs);
  }

  let sum = Number(num1) + Number(num2);
  if (sum < -1000000) {
    res.status(400).json(response.underflow);
  }
  if (sum > 1000000) {
    res.status(400).json(response.overflow);
  }

  res.status(200).json({
    status: "Success",
    message: "The sum of the given two numbers",
    sum: sum,
  });
});

app.post("/sub", (req, res) => {
  let num1 = req.body.num1;
  let num2 = req.body.num2;

  if (!checkValues(num1, num2)) {
    return res.status(400).json(response.checkValue);
  }
  if (!validateDataType(num1, num2)) {
    return res.status(400).json(response.invalidInputs);
  }

  let sub = Number(num1) - Number(num2);
  if (sub < -1000000) {
    res.status(400).json(response.underflow);
  }
  if (sub > 1000000) {
    res.status(400).json(response.overflow);
  }

  res.status(200).json({
    status: "Success",
    message: "The difference of the given two numbers",
    difference: sub
  });
});

app.post("/multiply", (req, res) => {
  let num1 = req.body.num1;
  let num2 = req.body.num2;

  if (!checkValues(num1, num2)) {
    return res.status(400).json(response.checkValue);
  }
  if (!validateDataType(num1, num2)) {
    return res.status(400).json(response.invalidInputs);
  }

  let multiply = Number(num1) * Number(num2);
  if (multiply < -1000000) {
    res.status(400).json(response.underflow);
  }
  if (multiply > 1000000) {
    res.status(400).json(response.overflow);
  }

  res.status(200).json({
    status: "Success",
    message: "The product of the given two numbers",
    multiply: multiply
  });
});

app.post("/divide", (req, res) => {
  let num1 = req.body.num1;
  let num2 = req.body.num2;

  if (!checkValues(num1, num2)) {
    return res.status(400).json(response.checkValue);
  }
  if (!validateDataType(num1, num2)) {
    return res.status(400).json(response.invalidInputs);
  }
  if (Number(num2) === 0) {
    return res.status(400).json({
      status: "Error",
      message: "Cannot divide by zero",
    });
  }

  let result = Number(num1) / Number(num2);
  if (result < -1000000) {
    res.status(400).json(response.underflow);
  }
  if (result > 1000000) {
    res.status(400).json(response.overflow);
  }

  res.status(200).json({
    status: "Success",
    message: "The quotient of the given two numbers",
    result: result
  });
});

app.get("*", (req, res) => {
  res.status(404).json({
    status: "Failed",
    message: " API not found"
  });
});

app.listen(9000, () => console.log("App running on port number 9000"));
